import React from 'react';
import logo from './logo.svg';
import './App.css';
import Tabla from './Components/Tabla';

function App() {
  return (
    <div className="App">
      <Tabla></Tabla>
    </div>
  );
}

export default App;
