import React, { Component } from 'react'
import TableCell from '@material-ui/core/TableCell';
import { withStyles, makeStyles } from '@material-ui/core/styles';


class Celda extends Component{

    constructor(props){
        super(props);

        this.state = {
            
            backgroundColor: "#FFFFFF",
            biggest: 93003,
            smallest: 12827
        }
    }

    componentDidMount = () => {

        if(typeof(this.props.info) === 'number'){

            const max = this.state.biggest - this.state.smallest
            const actual = this.props.info - this.state.smallest

            let perc = (actual * 255) / max
            perc = 255 - perc.toFixed(0)


            let hex = perc.toString(16)

            if (hex[1] === '.'){
                hex = '0' + hex[0]
            }
            else{
                hex = hex[0]+hex[1]
            }
            
            if (perc === 0){
                hex = '00'
            }
            // else if(perc === 255){
            //     hex = 'FF'
            // }
            console.log(perc, hex)

            this.setState({
                backgroundColor: '#FF'+hex+hex
            }, ()=>{
                if(perc === '255'){
                    console.log(this.state.backgroundColor)
                }
            })
        } 
    }

    render(){
        const StyledTableCell = withStyles(theme => ({
            root: {
                backgroundColor: this.state.backgroundColor,
            },
        }))(TableCell);

        return(
            <StyledTableCell align="right" >{this.props.info} </StyledTableCell>
        )
    }
}

export default Celda