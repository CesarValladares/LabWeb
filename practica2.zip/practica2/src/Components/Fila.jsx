import React, { Component } from 'react'
import Celda from './Celda';
import TableRow from '@material-ui/core/TableRow';

class Fila extends Component{

    constructor(props){
        super(props);
    }
    render(){
        return(
            <TableRow>

                {this.props.data.map((data, index) =>{
                    return(
                        <Celda info={data} index={index}></Celda>
                    )
                })}
            </TableRow>
        )
    }
}

export default Fila