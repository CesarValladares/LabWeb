var users = []

export const action_edit_data = (user) => dispatch => {
    console.log("EVENT", user)
    users.push(user)

    dispatch({
        type: 'EDIT',
        users
    })
}



// export function action_edit_data (event){
//     action = {
//         type: 'EDIT', 
//         event
//     }

//     dispatch(action)
// }