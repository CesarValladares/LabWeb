import React from 'react';
import './App.css';
import DatosPersonales from './Components/DatosPersonales';
import TableComponent from './Components/TableComponent';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <DatosPersonales ></DatosPersonales>
        <TableComponent></TableComponent>
      </header>
    </div>
  );
}

export default App;
