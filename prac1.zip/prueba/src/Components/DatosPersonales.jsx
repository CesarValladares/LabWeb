import React, { Component } from 'react'

class DatosPersonales extends Component {
    render(){
        return(
            <React.Fragment>
                <h1>César Armando Valladares Martínez</h1>
                <h2>A01023506</h2>
            </React.Fragment>
        )
    }
}   

export default DatosPersonales