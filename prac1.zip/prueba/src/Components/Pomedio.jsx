import React, { Component } from 'react'

class Promedio extends Component {

    constructor(props){
        super(props);

        this.state ={
            promedio: 0
        }
    }

    componentDidMount = () => {

        this.setState({
            promedio: (this.props.calf.ef + this.props.calf.lpf + this.props.calf.pf ) / 3
        })
    }

    render(){
        return(
            <React.Fragment>
                <h3>Promedio: {this.state.promedio}</h3>
            </React.Fragment>
        )
    }
}   

export default Promedio